rem Kevin Shibata
rem kkshibat@hotmail.com

drop table campuses cascade constraints;
drop table csufees cascade constraints;
drop table degrees cascade constraints;
drop table disciplineEnrollemnts cascade constraints;
drop table disciplines cascade constraints;
drop table enrollments cascade constraints;
drop table faculty cascade constraints;
