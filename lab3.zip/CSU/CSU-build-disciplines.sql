rem kevin shibata
rem kkshibat@calpoly.edu
INSERT INTO disciplines VALUES (1,'Agriculture');
INSERT INTO disciplines VALUES (2,'Architecture');
INSERT INTO disciplines VALUES (3,'Area Studies');
INSERT INTO disciplines VALUES (4,'Biological Sciences');
INSERT INTO disciplines VALUES (5,'Business and Management');
INSERT INTO disciplines VALUES (6,'Communications');
INSERT INTO disciplines VALUES (7,'Computer and Info. Sciences');
INSERT INTO disciplines VALUES (8,'Education');
INSERT INTO disciplines VALUES (9,'Engineering');
INSERT INTO disciplines VALUES (10,'Fine and Applied Arts');
INSERT INTO disciplines VALUES (11,'Foreign Languages');
INSERT INTO disciplines VALUES (12,'Health Professions');
INSERT INTO disciplines VALUES (13,'Home Economics');
INSERT INTO disciplines VALUES (14,'Interdisciplinary Studies');
INSERT INTO disciplines VALUES (15,'Letters');
INSERT INTO disciplines VALUES (16,'Library');
INSERT INTO disciplines VALUES (17,'Mathematics');
INSERT INTO disciplines VALUES (18,'Physical Sciences');
INSERT INTO disciplines VALUES (19,'Psychology');
INSERT INTO disciplines VALUES (20,'Public Affairs');
INSERT INTO disciplines VALUES (21,'Social Sciences');
INSERT INTO disciplines VALUES (22,'Undeclared');
