rem Kevin Shibata
rem kkshibat@hotmail.com

select * from campuses;
select * from csufees;
select * from degrees;
select * from disciplineEnrollemnts;
select * from disciplines;
select * from enrollments;
select * from faculty;
