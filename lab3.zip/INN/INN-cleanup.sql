rem kevin shibata
rem kkshibat@hotmail.com

drop table Rooms cascade constraits;
drop table Reservations cascade constraits;
