rem kevin shibata
rem kkshibat@hotmail.com

select * from Rooms;
select * from Reservations;
