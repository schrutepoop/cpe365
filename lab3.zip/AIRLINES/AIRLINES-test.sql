rem kevin shibata
rem kkshibat@calpoly.edu

select * from airlines;
select * from airport100;
select * from flights;
