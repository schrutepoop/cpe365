rem kevin shbibata
rem kkshibat@calpoly.edu

select * from list;
select * from teachers;
