rem kevin shibata
rem kkshibat@calpoly.edu

select * from marathon;
