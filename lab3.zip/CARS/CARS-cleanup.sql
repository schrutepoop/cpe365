rem kevin shibata
rem kkshbiat@calpoly.edu

drop table CarMakers cascade constraints;
drop table CarName cascade constraints;
drop table CarData cascade constraints;
drop table continents cascade constraints;
drop table countries cascade constraints;
drop table modelList cascade constraints;
