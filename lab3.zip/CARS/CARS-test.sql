rem kevin shibata
rem kkshbiat@calpoly.edu

select * from CarMakers;
select * from CarName;
select * from CarData;
select * from continents;
select * from countries;
select * from modelList;
