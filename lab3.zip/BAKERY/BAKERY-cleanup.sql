rem kevin shibata
rem kkshbat@calpoly.edu

drop table customers cascade constraints;
drop table goods cascade constraints;
drop table receipts cascade constraints;
drop table items cascade constraints;
