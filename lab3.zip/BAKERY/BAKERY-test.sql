rem kevin shibata
rem kkshbat@calpoly.edu

select * from customers;
select * from goods;
select * from receipts;
select * from items;
