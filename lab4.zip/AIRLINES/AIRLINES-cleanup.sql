rem Kevin Shibata
rem kkshibat@calpoly.edu

drop table airlines cascade constraints;
drop table airports100 cascade constraints;
drop table flights cascade constraints;
