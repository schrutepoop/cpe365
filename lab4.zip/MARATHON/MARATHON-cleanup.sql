rem kevin shibata
rem kkshibat@calpoly.edu

drop table marathon cascade constraints;
