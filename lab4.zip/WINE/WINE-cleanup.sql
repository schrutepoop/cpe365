rem kevin shibata
rem kkshibat@hotmail.com

drop table appelations cascade constraints;
drop table grapes cascade constraints;
drop table wine cascade constraints;
