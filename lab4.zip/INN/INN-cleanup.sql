rem kevin shibata
rem kkshibat@hotmail.com

drop table Rooms cascade constraints;
drop table Reservations cascade constraints;
