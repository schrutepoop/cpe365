rem kevin shbibata
rem kkshibat@calpoly.edu

drop table list cascade constraints;
drop table teachers cascade constraints;
